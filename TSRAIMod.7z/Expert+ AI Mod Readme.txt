TSR "Expert+" AI Mod

Quick tweaks to improve Expert AI for a tougher challenge, allowing offline
play to (somewhat) more closely mimic the experience of racing online.
It's also nice for more difficult co-op in Custom Lobbies.

To install, simply overwrite "<TSR install path>\data\gamedata\aiprofiles.dat"
Be sure to make a backup first! Or just use Steam's "Verify Game Files" to
uninstall later.

This mod tweaks the following AI pacing values:
-- Far Behind:
	-- Teammate: 1.4 -> 1.6
	-- Opponent: 1.4 -> 1.6
-- Close:
	-- Teammate: 1.0 -> 1.2
	-- Opponent: 1.08 -> 1.2
-- Far Ahead:
	-- Teammate: 0.7 -> 1.0
	-- Opponent: 0.8 -> 1.0

These changes apply anywhere on Expert except Adventure Mode, as those use
their own sets of values that I was too lazy to change.

Unfortunately, these changes can also potentially affect AI in Matchmaking.
However, TSR appears to round-robin network authority of AI, which means these
tweaks may or may not apply to your team - and may or may not apply to an
opponent's team(s) instead! So there doesn't appear to be a tangible benefit to
using this. As this is a non-issue in full games (no AI) - and having good
human teammates is still preferable anyway - I figured there wasn't much harm
in releasing this.

Random trivia:
-- Team Grand Prix appears to use Standard (Non-Team) AI profiles instead of
Team AI profiles, which is why you receive random AI teammates in Grand Prix.

-- Hard Team AI profiles in all modes (including Adventure Mode) appear to
accidentally be using Expert values instead. Oops! Standard AI, on the other
hand, have their own values defined for Hard.

Enjoy!
~fox
